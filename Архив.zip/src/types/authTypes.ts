export interface AuthData {
  isu_id: string;
  access_token: string;
  refresh_token: string;
  password: string;
}
